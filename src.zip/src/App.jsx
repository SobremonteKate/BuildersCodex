import React, { useEffect, useState } from "react";
import BlurText from "./components/BlurText";
import { useCodexProgress } from "./hooks/useCodexProgress";
import { Reveal } from "./hooks/Reveal";
import { LEVELS } from "./data/levels";
import { ACHIEVEMENT_CATEGORIES } from "./data/achievements";
import { DAILY_QUEST_TYPES, LOW_ENERGY } from "./data/dailyQuests";
import { MONTHLY_ROADMAP } from "./data/monthlyRoadmap";
import { PROJECTS } from "./data/projects";
import {
  REPOS,
  GITHUB_CARDS,
  RESUME_CARDS,
  PORTFOLIO_CARDS,
  FINAL_CHECKLIST,
  HOWTO_CARDS,
  SKILL_TAGS,
  UNLOCK_ORDER,
} from "./data/careerContent";
import { ACADEMIES, GITHUB_STATS_PLACEHOLDER, PROJECT_VAULT } from "./data/academies";
import { COLORS, NAV_LINKS } from "./data/misc";

/* ---------- helpers ---------- */

// turns `code` and **bold** markers inside plain strings into React nodes
function rich(str) {
  if (!str) return null;
  const parts = String(str).split(/(`[^`]+`|\*\*[^*]+\*\*)/g).filter((p) => p !== "");
  return parts.map((part, i) => {
    if (part.startsWith("`") && part.endsWith("`")) return <code key={i}>{part.slice(1, -1)}</code>;
    if (part.startsWith("**") && part.endsWith("**")) return <b key={i}>{part.slice(2, -2)}</b>;
    return <span key={i}>{part}</span>;
  });
}

/* ---------- main component ---------- */

export default function BuildersCodex() {
  const {
    checkedQuests,
    clearedBosses,
    unlockedAch,
    checkedLevelItems,
    levelStats,
    globalStats,
    totalAchCount,
    toast,
    toggleQuest,
    toggleBoss,
    toggleAch,
    toggleLevelItem,
    resetProgress,
  } = useCodexProgress();

  const [scrollPct, setScrollPct] = useState(0);
  const [showTop, setShowTop] = useState(false);
  const [activeSection, setActiveSection] = useState("");
  const [expandedAcademies, setExpandedAcademies] = useState(() => new Set(["software", "ai"]));

  function toggleAcademyExpansion(id) {
    setExpandedAcademies(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }

  useEffect(() => {
    function onScroll() {
      const el = document.documentElement;
      const scrolled = el.scrollTop || document.body.scrollTop;
      const height = el.scrollHeight - el.clientHeight;
      setScrollPct(height > 0 ? (scrolled / height) * 100 : 0);
      setShowTop(window.scrollY > 600);
    }
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    if (!("IntersectionObserver" in window)) return;
    const els = NAV_LINKS.map(([id]) => document.getElementById(id)).filter(Boolean);
    const obs = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) setActiveSection(entry.target.id);
        });
      },
      { rootMargin: "-40% 0px -55% 0px", threshold: 0 }
    );
    els.forEach((el) => obs.observe(el));
    return () => obs.disconnect();
  }, []);

  return (
    <div className="codex-root">
      <div className="scroll-progress" style={{ width: `${scrollPct}%` }} />

      <nav className="toc">
        <div className="toc-inner">
          <span className="toc-brand">⚡ CODEX</span>
          {NAV_LINKS.map(([id, label]) => (
            <a key={id} href={`#${id}`} className={activeSection === id ? "active" : ""}>{label}</a>
          ))}
        </div>
      </nav>

      {/* COVER */}
      <div className="cover">
        <div className="cover-inner">
          <div className="eyebrow-row">
            <span className="chip fullstack">� SOFTWARE</span>
            <span className="chip data">🤖 AI AUTOMATION</span>
            <span className="chip cloud">🟠 CLOUD</span>
            <span className="chip security">🔴 SECURITY</span>
            <span className="chip career">🟣 CAREER</span>
          </div>
         <BlurText
  text="CAREER OS"
  animateBy="letters"
  delay={45}
  stepDuration={0.55}
  className="codex-title"
  animationFrom={{
    opacity: 0,
    y: -80,
    scale: 1.25,
    filter: "blur(16px)",
  }}
  animationTo={[
    {
      opacity: 0.8,
      y: 8,
      scale: 1.08,
      filter: "blur(5px)",
    },
    {
      opacity: 1,
      y: -3,
      scale: 0.98,
      filter: "blur(0px)",
    },
    {
      opacity: 1,
      y: 0,
      scale: 1,
      filter: "blur(0px)",
    },
  ]}
/>
          <p className="sub">A dual academy dashboard for tracking Software Engineering and AI Automation progress. Level up, complete quests, and build a project vault while keeping your momentum visible.</p>
          <div className="stat-row">
            <div className="stat-card"><div className="num">6</div><div className="lbl">Levels (Months)</div></div>
            <div className="stat-card"><div className="num">24</div><div className="lbl">Weeks</div></div>
            <div className="stat-card"><div className="num">~480</div><div className="lbl">Total Hours</div></div>
            <div className="stat-card"><div className="num">4</div><div className="lbl">Flagship Projects</div></div>
            <div className="stat-card"><div className="num">{totalAchCount}</div><div className="lbl">Achievements</div></div>
            <div className="stat-card"><div className="num">{globalStats.levelsCleared}/{LEVELS.length}</div><div className="lbl">Levels Cleared</div></div>
            <div className="stat-card"><div className="num">{globalStats.totalXP.toLocaleString()}</div><div className="lbl">XP Earned</div></div>
          </div>
          <div className="overall-progress-wrap">
            <div className="overall-progress-label"><span>Overall Roadmap Progress</span><span>{globalStats.overallPct}%</span></div>
            <div className="overall-progress-track"><div className="overall-progress-fill" style={{ width: `${globalStats.overallPct}%` }} /></div>
            <p className="overall-progress-hint">Click any quest, boss battle, or achievement badge below to track it here. Progress is saved automatically.</p>
          </div>
        </div>
      </div>

      <div className="wrap">
        <section id="dashboard">
          <div className="section-head">
            <div className="section-tag">Mission Control</div>
            <h2 className="section-title">📊 Career OS Dashboard</h2>
            <p className="section-desc">Track both academies in one place: total XP, streaks, today's quests, boss battles, and independent progress summaries.</p>
          </div>
          <div className="dashboard-grid">
            <div className="dashboard-card">
              <div className="dash-label">Overall XP</div>
              <div className="dash-value">{globalStats.totalXP.toLocaleString()}</div>
              <div className="dash-meta">{globalStats.levelsCleared} levels cleared · {globalStats.overallPct}% complete</div>
            </div>
            <div className="dashboard-card">
              <div className="dash-label">Combined Streak</div>
              <div className="dash-value">{ACADEMIES.reduce((sum, academy) => sum + academy.currentStreak, 0)} days</div>
              <div className="dash-meta">Across both academies</div>
            </div>
            <div className="dashboard-card">
              <div className="dash-label">Today's Quests</div>
              <ul className="dash-list">
                {ACADEMIES.flatMap((academy) =>
                  academy.todayQuests.map((quest, qi) => (
                    <li key={`${academy.id}-${qi}`}><span className="dash-emoji">{academy.emoji}</span> {quest}</li>
                  ))
                )}
              </ul>
            </div>
            <div className="dashboard-card card-full">
              <div className="dash-label">Academy Progress</div>
              <div className="academy-summary-grid">
                {ACADEMIES.map((academy) => {
                  const pct = Math.round((academy.currentXP / academy.xpTotal) * 100);
                  const trackColor = COLORS[academy.colorKey] || COLORS.gold;
                  return (
                    <div className="academy-summary" key={academy.id}>
                      <div className="academy-title">{academy.emoji} {academy.name}</div>
                      <div className="academy-stat">Level {academy.currentLevel} · {academy.currentXP.toLocaleString()} XP</div>
                      <div className="pbar"><div className="pbar-fill" style={{ width: `${pct}%`, background: `linear-gradient(90deg, ${trackColor.fillA}, ${trackColor.fillB})` }} /></div>
                      <div className="academy-boss">Boss: {academy.currentBoss}</div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </section>

        {ACADEMIES.map((academy) => (
          <section id={academy.id} key={academy.id} className="academy-section">
            <div className="section-head">
              <div className="section-tag">{academy.emoji} {academy.name}</div>
              <h2 className="section-title">{academy.name}</h2>
              <p className="section-desc">{academy.description}</p>
            </div>
            <div className="grid grid-2">
              <Reveal className="card">
                <div className="h">Current Snapshot</div>
                <div className="dash-metrics">
                  <div className="metric"><span>Level</span><strong>{academy.currentLevel}</strong></div>
                  <div className="metric"><span>XP</span><strong>{academy.currentXP.toLocaleString()} / {academy.xpTotal.toLocaleString()}</strong></div>
                  <div className="metric"><span>Streak</span><strong>{academy.currentStreak} days</strong></div>
                  <div className="metric"><span>Boss</span><strong>{academy.currentBoss}</strong></div>
                </div>
              </Reveal>
              <Reveal className="card">
                <div className="h">Weekly Goals</div>
                <ul className="academy-goals">
                  {academy.weeklyGoals.map((goal, gi) => <li key={gi}>{goal}</li>)}
                </ul>
              </Reveal>
            </div>
            <div className="grid grid-2">
              <Reveal className="card">
                <div className="h">Skill Tree</div>
                <div className="academy-skill-grid">
                  {academy.skillTree.map((branch, bi) => (
                    <div key={bi} className="academy-skill-branch">
                      <div className="academy-skill-title">{branch.title}</div>
                      <ul>{branch.items.map((item) => <li key={item}>{item}</li>)}</ul>
                    </div>
                  ))}
                </div>
              </Reveal>
              <Reveal className="card">
                <div className="h">Upcoming Milestones</div>
                <ul className="academy-milestones">
                  {academy.upcomingMilestones.map((item, ii) => <li key={ii}>{item}</li>)}
                </ul>
              </Reveal>
            </div>
            <div className="grid grid-3">
              <Reveal className="card">
                <div className="h">Daily Quests</div>
                <ul className="academy-quest-list">
                  {academy.dailyQuests.map((dq, qi) => (
                    <li key={qi}>
                      <div className="academy-quest-time">{dq.time}</div>
                      <div className="academy-quest-detail">
                        <div className="academy-quest-label">{dq.label}</div>
                        <div className="academy-quest-examples">{dq.examples.join(" · ")}</div>
                      </div>
                    </li>
                  ))}
                </ul>
              </Reveal>
              <Reveal className="card">
                <div className="h">Monthly Roadmap</div>
                <ul className="academy-roadmap-list">
                  {academy.monthlyRoadmap.map((month) => (
                    <li key={month.id}>
                      <strong>{month.monthLabel}</strong>
                      <div className="academy-roadmap-title">{month.title}</div>
                    </li>
                  ))}
                </ul>
              </Reveal>
              <Reveal className="card">
                <div className="h">Achievement Path</div>
                {academy.achievements.map((cat, ci) => (
                  <div key={ci} className="academy-ach-category">
                    <div className="academy-ach-cat-title">{cat.title}</div>
                    <ul>
                      {cat.items.map(([emoji, name, desc], itemIdx) => (
                        <li key={`${name}-${itemIdx}`}><span>{emoji}</span> <strong>{name}</strong> — {desc}</li>
                      ))}
                    </ul>
                  </div>
                ))}
              </Reveal>
            </div>
          </section>
        ))}

        {/* PATH COMPARISON */}
        {(function() {
          const sw = ACADEMIES.find(a => a.id === "software");
          const ai = ACADEMIES.find(a => a.id === "ai");

          const swSkillTree = sw.skillTree.flatMap(b => b.items);
          const swProjectTags = sw.projects.flatMap(p => p.tags);
          const swAll = [...new Set([...swSkillTree, ...swProjectTags])];

          const aiSkillTree = ai.skillTree.flatMap(b => b.items);
          const aiLevelTechs = ai.levels.flatMap(l => l.technologies || []);
          const aiProjectTags = ai.projects.flatMap(p => p.tags);
          const aiAll = [...new Set([...aiSkillTree, ...aiLevelTechs, ...aiProjectTags])];

          const swLower = new Set(swAll.map(s => s.toLowerCase()));
          const aiLower = new Set(aiAll.map(s => s.toLowerCase()));

          const shared = swAll.filter(s => aiLower.has(s.toLowerCase())).sort();
          const swOnly = swAll.filter(s => !aiLower.has(s.toLowerCase())).sort();
          const aiOnly = aiAll.filter(s => !swLower.has(s.toLowerCase())).sort();

          return (
            <section id="comparison">
              <div className="section-head">
                <div className="section-tag">Cross-Academy Analysis</div>
                <h2 className="section-title">🔄 Path Comparison: Software vs AI</h2>
                <p className="section-desc">See which skills overlap between the two academies and which are unique to each track. This helps you decide whether to specialize in one, or combine both for maximum career versatility.</p>
              </div>

              {/* Stats overview */}
              <div className="comparison-stats">
                <div className="comparison-stat-card" style={{ borderLeftColor: COLORS.fullstack.dim }}>
                  <div className="comparison-stat-value" style={{ color: COLORS.fullstack.main }}>{swOnly.length}</div>
                  <div className="comparison-stat-label">Software-Only Skills</div>
                </div>
                <div className="comparison-stat-card" style={{ borderLeftColor: COLORS.gold.dim }}>
                  <div className="comparison-stat-value" style={{ color: COLORS.gold.main }}>{shared.length}</div>
                  <div className="comparison-stat-label">Shared Skills</div>
                </div>
                <div className="comparison-stat-card" style={{ borderLeftColor: COLORS.data.dim }}>
                  <div className="comparison-stat-value" style={{ color: COLORS.data.main }}>{aiOnly.length}</div>
                  <div className="comparison-stat-label">AI-Only Skills</div>
                </div>
                <div className="comparison-stat-card" style={{ borderLeftColor: COLORS.fullstack.dim }}>
                  <div className="comparison-stat-value" style={{ color: COLORS.fullstack.main }}>{swAll.length}</div>
                  <div className="comparison-stat-label">Total SW Skills</div>
                </div>
                <div className="comparison-stat-card" style={{ borderLeftColor: COLORS.data.dim }}>
                  <div className="comparison-stat-value" style={{ color: COLORS.data.main }}>{aiAll.length}</div>
                  <div className="comparison-stat-label">Total AI Skills</div>
                </div>
                <div className="comparison-stat-card" style={{ borderLeftColor: COLORS.career.dim }}>
                  <div className="comparison-stat-value" style={{ color: COLORS.career.main }}>{swAll.length + aiAll.length - shared.length}</div>
                  <div className="comparison-stat-label">Combined Unique Pool</div>
                </div>
              </div>

              {/* Insight callout */}
              <div className="callout" style={{ marginBottom: 28 }}>
                💡 <b>How to read this:</b> Focus on the <b>Shared Skills</b> column first — these foundational technologies (Docker, CI/CD, REST APIs) appear in both tracks and give you the most versatility per hour invested. Then choose your specialty: <span style={{ color: COLORS.fullstack.main }}>Software Engineering</span> for programming, UI, and infrastructure depth, or <span style={{ color: COLORS.data.main }}>AI Automation</span> for LLMs, agents, and workflow automation. Master both to become a uniquely hireable <b>AI Engineer</b>.
              </div>

              {/* 3-column skill comparison */}
              <div className="grid grid-3">
                <Reveal className="card comparison-card">
                  <div className="comparison-card-label" style={{ color: COLORS.fullstack.main }}>💻 Software Only</div>
                  <p className="comparison-card-desc">Unique to the programming-first track.</p>
                  <div className="tag-row">
                    {swOnly.map(s => <span key={s} className="tag">{s}</span>)}
                  </div>
                </Reveal>

                <Reveal className="card comparison-card">
                  <div className="comparison-card-label" style={{ color: COLORS.gold.main }}>🔄 Shared</div>
                  <p className="comparison-card-desc">Foundational skills both academies build.</p>
                  <div className="tag-row">
                    {shared.map(s => <span key={s} className="tag">{s}</span>)}
                  </div>
                </Reveal>

                <Reveal className="card comparison-card">
                  <div className="comparison-card-label" style={{ color: COLORS.data.main }}>🤖 AI Only</div>
                  <p className="comparison-card-desc">Unique to the AI automation track.</p>
                  <div className="tag-row">
                    {aiOnly.map(s => <span key={s} className="tag">{s}</span>)}
                  </div>
                </Reveal>
              </div>

              {/* Project focus comparison */}
              <Reveal className="card comparison-card-wide" style={{ marginTop: 28 }}>
                <div className="h">🏗️ Project Focus Comparison</div>
                <div className="comparison-projects-grid">
                  <div className="comparison-project-side">
                    <div className="comparison-project-side-title" style={{ color: COLORS.fullstack.main }}>💻 Software Engineering Projects</div>
                    <div className="comparison-project-side-desc">Build, deploy, and secure applications. Output is a <b>product</b> — something users interact with.</div>
                    <div className="comparison-project-side-list">
                      <div className="comparison-project-item">
                        <div className="comparison-project-name">MarleHotelDB</div>
                        <div className="comparison-project-type">SaaS platform with CI/CD, Docker, cloud infrastructure</div>
                      </div>
                      <div className="comparison-project-item">
                        <div className="comparison-project-name">SentinelScan</div>
                        <div className="comparison-project-type">Security CLI tool with OWASP scanning, CVE lookup</div>
                      </div>
                      <div className="comparison-project-item">
                        <div className="comparison-project-name">Portfolio v2</div>
                        <div className="comparison-project-type">Personal brand site, design system, deploy previews</div>
                      </div>
                    </div>
                  </div>
                  <div className="comparison-project-divider"></div>
                  <div className="comparison-project-side">
                    <div className="comparison-project-side-title" style={{ color: COLORS.data.main }}>🤖 AI Automation Projects</div>
                    <div className="comparison-project-side-desc">Design workflows, train agents, automate processes. Output is a <b>system</b> — something that operates autonomously.</div>
                    <div className="comparison-project-side-list">
                      <div className="comparison-project-item">
                        <div className="comparison-project-name">AI Prompt Library</div>
                        <div className="comparison-project-type">Multi-model prompt management, cost optimization, A/B testing</div>
                      </div>
                      <div className="comparison-project-item">
                        <div className="comparison-project-name">Multi-Agent RAG</div>
                        <div className="comparison-project-type">Document intelligence, vector search, agent orchestration</div>
                      </div>
                      <div className="comparison-project-item">
                        <div className="comparison-project-name">Business Automation Suite</div>
                        <div className="comparison-project-type">Email triage, CRM pipelines, support agent, meeting intelligence</div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="comparison-project-takeaway">
                  <b>Key insight:</b> Software projects prove you can <b>build</b> products. AI projects prove you can <b>automate</b> processes. Employers hiring for AI Engineer roles want both.
                </div>
              </Reveal>
            </section>
          );
        })()}

        {/* ACADEMY LEVEL PROGRESSION */}
        <section id="level-progression">
          <div className="section-head">
            <div className="section-tag">Skill Breakdown</div>
            <h2 className="section-title">✦ Academy Level Progression</h2>
            <p className="section-desc">Detailed breakdown of every level in each academy. Expand to see objectives, technologies, skills unlocked, resume impact, GitHub repos, and mini projects.</p>
          </div>

          {/* Toggle pills */}
          <div className="lp-toggles">
            {ACADEMIES.map(academy => {
              const c = COLORS[academy.colorKey] || COLORS.gold;
              const active = expandedAcademies.has(academy.id);
              return (
                <button
                  key={academy.id}
                  className={`lp-toggle${active ? " active" : ""}`}
                  style={{
                    borderColor: active ? c.dim : undefined,
                    background: active ? `${c.main}14` : undefined,
                    color: active ? c.main : undefined,
                  }}
                  onClick={() => toggleAcademyExpansion(academy.id)}
                >
                  {active ? "▼" : "▶"} {academy.emoji} {academy.name}
                </button>
              );
            })}
          </div>

          {/* Level cards */}
          {ACADEMIES.map(academy => {
            const academyColor = COLORS[academy.colorKey] || COLORS.gold;
            const expanded = expandedAcademies.has(academy.id);
            return (
              <div key={academy.id} className={`lp-academy${expanded ? " expanded" : ""}`}>
                <div className="lp-academy-header" onClick={() => toggleAcademyExpansion(academy.id)}>
                  <div className="lp-academy-badge" style={{ background: academyColor.dim, color: academyColor.main }}>
                    {academy.emoji}
                  </div>
                  <div className="lp-academy-info">
                    <div className="lp-academy-name">{academy.name}</div>
                    <div className="lp-academy-meta">{academy.levels.length} levels · {academy.levels.reduce((s, l) => s + l.xp, 0).toLocaleString()} total XP</div>
                  </div>
                  <span className="lp-chevron" style={{ color: expanded ? academyColor.main : "var(--text-faint)" }}>
                    {expanded ? "▲" : "▼"}
                  </span>
                </div>
                <div className="lp-academy-body">
                  {academy.levels.map((lvl, li) => {
                    const lvlColor = COLORS[lvl.colorKey] || COLORS.gold;
                    return (
                      <div key={li} className={`lp-level${expanded ? " show" : ""}`} style={{ transitionDelay: `${li * 60}ms` }}>
                        <div className="academy-level-card" style={{ borderLeftColor: lvlColor.dim }}>
                          <div className="academy-level-header">
                            <div className="academy-level-badge" style={{ background: lvlColor.dim, color: lvlColor.main }}>{lvl.num}</div>
                            <div className="academy-level-info">
                              <div className="academy-level-name">{lvl.name}</div>
                              <div className="academy-level-meta">{lvl.track} · {lvl.xp.toLocaleString()} XP · Unlocks: {lvl.unlocks}</div>
                            </div>
                          </div>
                          <div className="academy-level-body">
                            {lvl.objective && (
                              <div className="academy-level-field">
                                <span className="academy-level-label">🎯 Objective</span>
                                <p className="academy-level-text">{lvl.objective}</p>
                              </div>
                            )}
                            {lvl.technologies && lvl.technologies.length > 0 && (
                              <div className="academy-level-field">
                                <span className="academy-level-label">🛠️ Tech Stack</span>
                                <div className="tag-row">{lvl.technologies.map(t => {
                                  const tid = `${academy.id}/${li}/t/${t}`;
                                  const done = checkedLevelItems.has(tid);
                                  return <span key={t} className={`tag clickable-tag${done ? " checked" : ""}`} onClick={() => toggleLevelItem(tid)}>{done ? "✔ " : "☐ "}{t}</span>;
                                })}</div>
                              </div>
                            )}
                            {lvl.skillsUnlocked && lvl.skillsUnlocked.length > 0 && (
                              <div className="academy-level-field">
                                <span className="academy-level-label">⚡ Skills Unlocked</span>
                                <div className="tag-row">{lvl.skillsUnlocked.map(s => {
                                  const sid = `${academy.id}/${li}/s/${s}`;
                                  const done = checkedLevelItems.has(sid);
                                  return <span key={s} className={`tag clickable-tag${done ? " checked" : ""}`} onClick={() => toggleLevelItem(sid)}>{done ? "✔ " : "☐ "}{s}</span>;
                                })}</div>
                              </div>
                            )}
                            {lvl.resumeOutcome && (
                              <div className="academy-level-field">
                                <span className="academy-level-label">📄 Resume Impact</span>
                                <p className="academy-level-resume">{rich(lvl.resumeOutcome)}</p>
                              </div>
                            )}
                            {lvl.githubRepo && (
                              <div className="academy-level-field">
                                <span className="academy-level-label">📦 Repo</span>
                                <div className="academy-level-github"><code>{lvl.githubRepo}</code></div>
                              </div>
                            )}
                            {lvl.miniProjects && lvl.miniProjects.length > 0 && (
                              <div className="academy-level-field">
                                <span className="academy-level-label">🏗️ Mini Projects</span>
                                <div className="academy-level-mini-grid">
                                  {lvl.miniProjects.map((mp, mpi) => (
                                    <details key={mpi} className="academy-level-mini">
                                      <summary className="academy-level-mini-summary">
                                        <span
                                          className={`clickable-project${checkedLevelItems.has(`${academy.id}/${li}/p/${mp.title}`) ? " checked" : ""}`}
                                          onClick={(e) => { e.stopPropagation(); toggleLevelItem(`${academy.id}/${li}/p/${mp.title}`); }}
                                        >
                                          {checkedLevelItems.has(`${academy.id}/${li}/p/${mp.title}`) ? "✔ " : "☐ "}{mp.title}
                                        </span>
                                      </summary>
                                      <div className="academy-level-mini-body">
                                        <div className="proj-block"><div className="h">Purpose</div>{mp.purpose}</div>
                                        <div className="proj-block"><div className="h">Features</div>{mp.features}</div>
                                        <div className="proj-block"><div className="h">Tech</div>{mp.tech}</div>
                                        <div className="proj-block"><div className="h">Skills</div>{mp.skillsLearned}</div>
                                        <div className="proj-block"><div className="h">Portfolio</div>{mp.portfolioValue}</div>
                                      </div>
                                    </details>
                                  ))}
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </section>

        {/* HOW TO READ */}
        <section id="howto">
          <div className="section-head">
            <div className="section-tag">Player Guide</div>
            <h2 className="section-title">How This Codex Works</h2>
            <p className="section-desc">Five tracks, color-coded so you always know what kind of work you're doing. Each month is a Level with a set of Quests and one Boss Battle. Each week has ~20 hours of assigned tasks — never more. Courses are pre-filtered: only the specific modules that matter are named. Everything else is explicitly skippable.</p>
          </div>
          <div className="grid grid-3">
            {HOWTO_CARDS.map(([h, body], i) => (
              <Reveal key={i} className="card">
                <div className="h">{h}</div>
                <p style={{ fontSize: 13.5, color: "var(--text-dim)", margin: 0 }}>{rich(body)}</p>
              </Reveal>
            ))}
          </div>
        </section>

        {/* SKILL TREE */}
        <section id="skilltree">
          <div className="section-head">
            <div className="section-tag">Character Build</div>
            <h2 className="section-title">🌳 Skill Tree</h2>
            <p className="section-desc">What you're keeping from your current build, and the branches you're unlocking, in order.</p>
          </div>
          <div className="grid grid-2">
            <Reveal className="card">
              <div className="h" style={{ color: "var(--fullstack)" }}>✅ Already Unlocked</div>
              <div className="tag-row">{SKILL_TAGS.map((t) => <span className="tag" key={t}>{t}</span>)}</div>
            </Reveal>
            <Reveal className="card">
              <div className="h" style={{ color: "var(--gold)" }}>🔓 Unlock Order (Jul → Dec)</div>
              <ol style={{ margin: 0, paddingLeft: 18, fontSize: 13.5, color: "var(--text-dim)", display: "flex", flexDirection: "column", gap: 6 }}>
                {UNLOCK_ORDER.map(([text, month, colorKey], i) => (
                  <li key={i}>{text} <span className="pill" style={{ borderColor: COLORS[colorKey].dim, color: COLORS[colorKey].main }}>{month}</span></li>
                ))}
              </ol>
            </Reveal>
          </div>
        </section>

        {/* LEVELS */}
        <section id="levels">
          <div className="section-head">
            <div className="section-tag">Progression System</div>
            <h2 className="section-title">🎮 The 6 Levels</h2>
            <p className="section-desc">Every level = one month. Clear the Quests, clear the Boss Battle, unlock the next track.</p>
          </div>
          {LEVELS.map((lvl, li) => {
            const c = COLORS[lvl.colorKey];
            const stats = levelStats[li];
            const bossCleared = clearedBosses.has(li);
            return (
              <Reveal key={li} className="level">
                <div className="level-head">
                  <div className="level-head-left">
                    <div className={`level-badge${stats.cleared ? " cleared" : ""}`} style={{ background: c.dim, color: c.main }}>{lvl.num}</div>
                    <div>
                      <p className="level-name">{lvl.name}</p>
                      <p className="level-meta">{lvl.month} · {lvl.track} · {lvl.xp.toLocaleString()} XP</p>
                    </div>
                  </div>
                  <span className="pill">Unlocks: {lvl.unlocks}</span>
                </div>
                <div className="level-body">
                  <div className="pbar"><div className="pbar-fill" style={{ width: `${stats.pct}%`, background: `linear-gradient(90deg, ${c.fillA}, ${c.fillB})` }} /></div>
                  <div style={{ height: 18 }} />
                  <ul className="quest-list">
                    {lvl.quests.map((q, qi) => {
                      const checked = checkedQuests.has(`${li}-${qi}`);
                      return (
                        <li key={qi} className={checked ? "q-checked" : ""} onClick={() => toggleQuest(li, qi)}>
                          {rich(q)}
                        </li>
                      );
                    })}
                  </ul>
                  <div className={`boss${bossCleared ? " b-cleared" : ""}`} onClick={() => toggleBoss(li)}>
                    <div className="lbl">⚔ BOSS BATTLE{bossCleared ? " · CLEARED ✔" : ""}</div>
                    {rich(lvl.boss)}
                  </div>
                  <div className="reward">{lvl.rewardIcon} <b>{lvl.isFinal ? "Final Reward:" : "Reward:"}</b> {rich(lvl.reward)}</div>
                </div>
              </Reveal>
            );
          })}
        </section>

        {/* ACHIEVEMENTS */}
        <section id="achievements">
          <div className="section-head">
            <div className="section-tag">Trophy Case</div>
            <h2 className="section-title">🏅 Achievements ({totalAchCount})</h2>
            <p className="section-desc">Unlockable in any order. Screenshot them, track them, put the best ones in your resume bullet points.</p>
          </div>
          {ACHIEVEMENT_CATEGORIES.map((cat, ci) => (
            <React.Fragment key={ci}>
              <div className="ach-cat-title">{cat.title}</div>
              <div className="grid grid-4">
                {cat.items.map(([emoji, name, desc], ii) => {
                  const id = `${ci}-${ii}`;
                  const unlocked = unlockedAch.has(id);
                  return (
                    <Reveal key={id} className={`ach${unlocked ? " unlocked" : ""}`} onClick={() => toggleAch(id, name)}>
                      <span className="emoji">{emoji}</span>
                      <div><div className="name">{name}</div><div className="desc">{desc}</div></div>
                    </Reveal>
                  );
                })}
              </div>
            </React.Fragment>
          ))}
        </section>

        {/* DAILY QUESTS */}
        <section id="dailyquests">
          <div className="section-head">
            <div className="section-tag">Combat System</div>
            <h2 className="section-title">⏱️ Daily Quest Types</h2>
            <p className="section-desc">Every quest in the monthly roadmaps below is tagged as one of these. Pick based on the energy you actually have today — not the energy you wish you had.</p>
          </div>
          <div className="grid grid-3">
            {DAILY_QUEST_TYPES.map((dq, i) => {
              const c = COLORS[dq.colorKey];
              return (
                <Reveal key={i} className="dq-card" style={{ borderColor: c.dim, background: `linear-gradient(135deg, ${c.main}0d, transparent)` }}>
                  <div className="dq-time" style={{ color: c.main }}>{dq.time}</div>
                  <div className="dq-label">{dq.label}</div>
                  <ul className="dq-examples">{dq.examples.map((e, ei) => <li key={ei}>{e}</li>)}</ul>
                </Reveal>
              );
            })}
            <Reveal className="dq-card" style={{ gridColumn: "span 2", borderColor: COLORS[LOW_ENERGY.colorKey].dim, background: `linear-gradient(135deg, ${COLORS[LOW_ENERGY.colorKey].main}0d, transparent)` }}>
              <div className="dq-time" style={{ color: COLORS[LOW_ENERGY.colorKey].main }}>🪫 Low Energy Mode</div>
              <div className="dq-label">{LOW_ENERGY.label}</div>
              <ul className="dq-examples">{LOW_ENERGY.examples.map((e, ei) => <li key={ei}>{e}</li>)}</ul>
            </Reveal>
          </div>
          <div style={{ height: 16 }} />
          <div className="callout">💡 <b>Weekly budget rule:</b> ~20 hrs/week ≈ roughly 3 Medium + 2 Hard + 1 Deep Work session, distributed across whichever days school/thesis/OJT leave open. Reshuffle freely — the Level and Boss Battle are what matter, not which day you did what.</div>
        </section>
      </div>

      {/* MONTHLY ROADMAPS */}
      <div className="wrap">
        {MONTHLY_ROADMAP.map((m) => (
          <section id={m.id} key={m.id}>
            <div className="section-head">
              <div className="section-tag">{m.monthLabel}</div>
              <h2 className="section-title">{m.title}</h2>
              <p className="section-desc">{m.desc}</p>
            </div>
            <table>
              <tbody>
                <tr><th>Week</th><th>Focus</th><th>Resource / Module</th><th>Key Tasks</th><th>Hrs</th></tr>
                {m.weeks.map((w, wi) => (
                  <tr key={wi}>
                    <td className="wk-tag">{w[0]}</td>
                    <td>{w[1]}</td>
                    <td>{rich(w[2])}</td>
                    <td>{rich(w[3])}</td>
                    <td>{w[4]}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div className="boss static" style={{ marginTop: 20 }}><div className="lbl">⚔ MONTH BOSS BATTLE</div>{rich(m.boss)}</div>
          </section>
        ))}
      </div>

      {/* PROJECTS */}
      <div className="wrap">
        <section id="projects">
          <div className="section-head">
            <div className="section-tag">Inventory</div>
            <h2 className="section-title">🏗️ Project Vault — Software vs AI</h2>
            <p className="section-desc">Projects are grouped by academy to keep software engineering work separate from AI automation workflows.</p>
          </div>
          {[
            { id: "software", title: "💻 Software Engineering" },
            { id: "ai", title: "🤖 AI Automation" },
          ].map((group) => {
            const items = PROJECTS.filter((project) => project.academy === group.id);
            return (
              <div key={group.id} className="project-group">
                <div className="project-group-title">{group.title}</div>
                <p className="project-group-desc">{PROJECT_VAULT.find((vault) => vault.title === group.title)?.description}</p>
                {items.map((p, pi) => (
                  <Reveal key={pi} className="proj">
                    <div className="proj-head">
                      <div><p className="proj-title">{p.title} <span className="pill" style={{ marginLeft: 8 }}>{p.badge}</span></p><span className="stars">{"★".repeat(p.stars)}{"☆".repeat(5 - p.stars)}</span></div>
                      <div className="tag-row">{p.tags.map((t) => <span className="tag" key={t}>{t}</span>)}</div>
                    </div>
                    <div className="proj-body">
                      {p.blocks.map(([h, body], bi) => (
                        <div className="proj-block" key={bi}><div className="h">{h}</div>{rich(body)}</div>
                      ))}
                    </div>
                  </Reveal>
                ))}
              </div>
            );
          })}
        </section>

        {/* GITHUB */}
        <section id="github">
          <div className="section-head">
            <div className="section-tag">Base Camp</div>
            <h2 className="section-title">🐙 GitHub Plan</h2>
          </div>
          <div className="dashboard-grid github-stats-grid">
            {GITHUB_STATS_PLACEHOLDER.map((stat) => (
              <div key={stat.label} className="dashboard-card github-stat">
                <div className="dash-label">{stat.label}</div>
                <div className="dash-value">{stat.value}</div>
              </div>
            ))}
          </div>
          <div className="grid grid-2">
            <Reveal className="card">
              <h3 className="sub-h">Repositories (pin these 4)</h3>
              <table>
                <tbody>
                  <tr><th>Repo</th><th>Purpose</th></tr>
                  {REPOS.map(([repo, purpose]) => (
                    <tr key={repo}><td><code>{repo}</code></td><td>{purpose}</td></tr>
                  ))}
                </tbody>
              </table>
              <p style={{ fontSize: 12.5, color: "var(--text-faint)", marginTop: 10 }}>Optional 5th: a <code>devlog</code> repo for weekly progress notes — cheap way to build commit consistency.</p>
            </Reveal>
            <Reveal className="card">
              <h3 className="sub-h">README Template</h3>
              <p style={{ fontSize: 13, color: "var(--text-dim)" }}>Every pinned repo needs: one-line pitch → live demo link → screenshot/GIF → tech stack badges → "Features" → "Getting Started" → "Architecture" (1 diagram) → "What I'd improve next".</p>
            </Reveal>
          </div>
          <div className="grid grid-3" style={{ marginTop: 28 }}>
            {GITHUB_CARDS.map(([h, body], i) => (
              <Reveal key={i} className="card">
                <h3 className="sub-h">{h}</h3>
                <p style={{ fontSize: 13, color: "var(--text-dim)" }}>{rich(body)}</p>
              </Reveal>
            ))}
          </div>
        </section>

        {/* RESUME */}
        <section id="resume">
          <div className="section-head">
            <div className="section-tag">Character Sheet</div>
            <h2 className="section-title">📄 Resume Plan — By December</h2>
          </div>
          <div className="grid grid-2">
            {RESUME_CARDS.map(([h, body], i) => (
              <Reveal key={i} className="card">
                <h3 className="sub-h">{h}</h3>
                <p style={{ fontSize: 13, color: "var(--text-dim)" }}>{rich(body)}</p>
              </Reveal>
            ))}
          </div>
        </section>

        {/* PORTFOLIO */}
        <section id="portfolio">
          <div className="section-head">
            <div className="section-tag">Home Base</div>
            <h2 className="section-title">🖥️ Portfolio Website Structure</h2>
          </div>
          <div className="grid grid-3">
            {PORTFOLIO_CARDS.map(([h, body], i) => (
              <Reveal key={i} className="card">
                <h3 className="sub-h">{h}</h3>
                <p style={{ fontSize: 13, color: "var(--text-dim)" }}>{body}</p>
              </Reveal>
            ))}
          </div>
        </section>

        {/* FINAL CHECKLIST */}
        <section id="checklist">
          <div className="section-head">
            <div className="section-tag">End Credits</div>
            <h2 className="section-title">✅ Final Checklist — December</h2>
          </div>
          <ul className="check-final">
            {FINAL_CHECKLIST.map((item, i) => <li key={i}>{item}</li>)}
          </ul>
        </section>
      </div>

      <footer>Built for the road from July to December. Track it, don't perfect it — a done week beats a perfect week.</footer>

      <div className="fab-group">
        <div className={`fab${showTop ? " show" : ""}`} title="Back to top" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}>↑</div>
        <div className="fab show" title="Reset progress" onClick={resetProgress}>↺</div>
      </div>

      <div className={`toast${toast.show ? " show" : ""}`}>{toast.msg}</div>
    </div>
  );
}