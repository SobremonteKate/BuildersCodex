// The 4 flagship portfolio projects. Each block is [heading, body].
export const PROJECTS = [
  {
    academy: "software",
    title: "1. MarleHotelDB — Cloud Edition", badge: "Capstone, upgraded", stars: 4,
    tags: ["PHP", "Docker", "AWS (EC2/RDS)", "GitHub Actions", "Claude API"],
    blocks: [
      ["Goal", "Turn your existing hotel management capstone into a cloud-deployed, secured, CI/CD-driven, AI-augmented SaaS-style platform."],
      ["Features", "RBAC across superadmin/admin/employee, booking engine, AI concierge assistant, audit logs, hardened auth."],
      ["Stretch Goals", "Multi-tenant support, Stripe test-mode payments, analytics dashboard for occupancy trends."],
      ["GitHub Structure", "`/app` `/docker` `/infra` `/docs` `/.github/workflows`"],
      ["Skills Learned", "Cloud deployment, IaC, CI/CD, security hardening, applied AI integration."],
      ["Resume Impact", "\"Deployed and secured a full-stack SaaS hotel management platform on AWS with automated CI/CD and an AI-powered concierge assistant, serving role-based access across 3 user tiers.\""],
      ["Estimated Hours", "~65 hrs, spread across Aug–Nov as enhancement waves."],
    ],
  },
  {
    academy: "software",
    title: "2. SentinelScan", badge: "New build", stars: 4,
    tags: ["Python", "FastAPI", "React", "Docker"],
    blocks: [
      ["Goal", "CLI + web dashboard tool that scans a target web app for common OWASP Top 10 issues, within legal/consented scope."],
      ["Features", "Security header analysis, dependency CVE lookup, exposed-file checks, PDF report export."],
      ["Stretch Goals", "Scheduled scans, Slack/webhook alerts, published Docker image."],
      ["GitHub Structure", "`/cli` `/api` `/web` `/reports` `/tests`"],
      ["Skills Learned", "Applied security fundamentals, Python tooling, API design."],
      ["Resume Impact", "\"Built and open-sourced a security scanning tool that detects OWASP Top 10 vulnerabilities via automated header, dependency, and exposure checks.\""],
      ["Estimated Hours", "~45 hrs, built across Sep–Oct."],
    ],
  },
  {
    academy: "ai",
    title: "3. DataPulse", badge: "New build", stars: 3,
    tags: ["Python / pandas", "AWS S3 + Glue", "Next.js", "Claude API"],
    blocks: [
      ["Goal", "End-to-end ETL pipeline on a public dataset, visualized in a dashboard with AI-generated narrative insights."],
      ["Features", "Scheduled ingestion, data cleaning pipeline, interactive charts, AI-written trend summaries."],
      ["Stretch Goals", "Basic anomaly detection, lightweight streaming ingestion."],
      ["GitHub Structure", "`/etl` `/dashboard` `/notebooks` `/docs`"],
      ["Skills Learned", "Data engineering, ETL design, dashboarding, AI-assisted analytics."],
      ["Resume Impact", "\"Engineered an end-to-end data pipeline and built an AI-augmented analytics dashboard surfacing trend insights automatically.\""],
      ["Estimated Hours", "~45 hrs, built in November."],
    ],
  },
  {
    academy: "software",
    title: "4. Personal Portfolio Website v2", badge: "Meta-project", stars: 3,
    tags: ["Next.js", "Tailwind", "Framer Motion"],
    blocks: [
      ["Goal", "Your personal brand as a live product — this is itself a portfolio piece recruiters will judge."],
      ["Features", "Project showcase, devlog/blog, animated roadmap timeline, dark mode, resume page."],
      ["Stretch Goals", "Blog RSS feed, view-count/analytics widget, guestbook."],
      ["Skills Learned", "Frontend polish, motion design restraint, personal brand writing."],
      ["Resume Impact", "Functions as the resume's landing page — every other project links back here."],
      ["Estimated Hours", "~30 hrs total: v1 in July, v2 polish in December."],
    ],
  },
];